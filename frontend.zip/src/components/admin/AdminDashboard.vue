<!-- src/views/admin/AdminDashboard.vue -->
<template>
  <div>
    <h2>관리자 대시보드</h2>
    <p>관리자용 요약 정보 표시</p>
  </div>
</template>
